// Archivo principal de JavaScript
document.addEventListener('DOMContentLoaded', function () {
    console.log('Sistema de pedidos cargado.');
});