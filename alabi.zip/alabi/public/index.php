<?php
session_start();
header('Location: app/Pedidos/pedidos.php');
exit();
?>